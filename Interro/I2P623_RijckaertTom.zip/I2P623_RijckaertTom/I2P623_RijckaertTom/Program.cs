﻿namespace I2P623_RijckaertTom
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Feu Vert");

            




        }
    }
}